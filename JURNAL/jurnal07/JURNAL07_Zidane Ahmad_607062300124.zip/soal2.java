package jurnal07;

public class soal2 {
    public static void main(String[] args) {
        
        for (int i = 1; i <= 10; i++){
            int hasilKuadrat = i * i;
            System.out.print(hasilKuadrat + " ");
        }
    }
}
