package jurnal11;
public class soal2 {
    public static void main (String [] args){
        
    }
}
