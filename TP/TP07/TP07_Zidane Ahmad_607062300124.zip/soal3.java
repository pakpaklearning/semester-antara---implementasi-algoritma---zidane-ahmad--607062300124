package TP07;

import java.util.Scanner;

public class soal3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int input = s.nextInt();
        int hasil = 0;

        for (int i = input; i > hasil; i--){
        System.out.println(i);
        }
        System.out.println("Go!!!");

    }
}
