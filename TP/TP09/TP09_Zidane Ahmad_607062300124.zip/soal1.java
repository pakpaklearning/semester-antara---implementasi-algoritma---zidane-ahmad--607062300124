package TP09;

public class soal1 {
        public static void main( final String[] args) {
            int n = 5;
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                System.out.println(); 
            }
        }
    }

