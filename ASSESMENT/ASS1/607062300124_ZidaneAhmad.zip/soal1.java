package ASSESMENT.ASS1;

import java.util.Scanner;

public class soal1 {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Jabatan Karyawan: ");
        String posisi = s.nextLine();
        System.out.print("Jam kerja sebulan: ");
        int jamKerja = s.nextInt();
        
        double gajiPerJam = 50000;
        double tunjangan = getAllowance(posisi);
        
        if (tunjangan == -1) {
            System.out.println("Jabatan tidak valid.");
            return;
        }
        
        double totalGaji = calculateSalary(jamKerja, gajiPerJam, tunjangan);
        totalGaji = applyBonus(jamKerja, totalGaji);
        
        System.out.printf("Total honor satu bulan: %.1f\n", totalGaji);
    }
    
    public static double getAllowance(String posisi) {
        switch (posisi) {
            case "MGR":
                return 1000000;
            case "STF":
                return 500000;
            case "TCH":
                return 750000;
            case "DRV":
                return 350000;
            default:
                return -1; // Invalid position
        }
    }
    
    public static double calculateSalary(int jamKerja, double gajiPerJam, double tunjangan) {
        return jamKerja * gajiPerJam + tunjangan;
    }
    
    public static double applyBonus(int jamKerja, double totalGaji) {
        if (jamKerja > 170) {
            return totalGaji + totalGaji * 0.07; // Bonus 7%
        } else if (jamKerja > 160) {
            return totalGaji + totalGaji * 0.05; // Bonus 5%
        } else {
            return totalGaji;
        }
    }
}